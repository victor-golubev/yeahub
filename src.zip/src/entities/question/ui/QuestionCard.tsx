import type { QuestionPreview } from '@/entities/question/model/types'
import accordeon from '@/shared/assets/images/accordeon.svg'
import { cn } from '@/shared/lib/utils/cn'
import { memo, useState } from 'react'
import { Link } from 'react-router-dom'
import styles from './QuestionCard.module.css'

interface QuestionCardProps {
	question: QuestionPreview
}

export const QuestionCard = memo(({ question }: QuestionCardProps) => {
	const { id, title, complexity, rate } = question
	const [isOpen, setIsOpen] = useState(false)

	return (
		<article
			className={styles.card}
			onClick={() => setIsOpen(prev => !prev)}
			aria-expanded={isOpen}
		>
			<div className={styles.header}>
				<p className={styles.title}>{title}</p>

				<button
					type="button"
					className={styles.show}
				>
					<img
						src={accordeon}
						alt="Детали вопроса"
						className={isOpen ? styles.iconOpen : styles.icon}
					/>
				</button>
			</div>

			<div className={cn(styles.body, isOpen && styles.bodyOpen)}>
				<div className={styles.info}>
					<div className={styles.meta}>
						<p className={styles.meta__item}>
							Рейтинг: <span className={styles.digit}>{rate}</span>
						</p>

						<p className={styles.meta__item}>
							Сложность: <span className={styles.digit}>{complexity}</span>
						</p>
					</div>

					<Link
						to={`/questions/${id}`}
						className={styles.link}
					>
						Подробнее →
					</Link>
				</div>

				<div className={styles.text}>{question.shortAnswer}</div>
			</div>
		</article>
	)
})
