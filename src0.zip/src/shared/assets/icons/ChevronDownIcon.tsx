export const ChevronDownIcon = ({ className }: { className?: string }) => (
	<svg
		className={className}
		width="16"
		height="8"
		viewBox="0 0 16 8"
		xmlns="http://www.w3.org/2000/svg"
		fill="none"
	>
		<path
			fill-rule="evenodd"
			clip-rule="evenodd"
			d="M0.180571 0.26192C0.450138 -0.0525743 0.923613 -0.0889955 1.23811 0.180571L7.75001 5.76221L14.2619 0.180572C14.5764 -0.0889949 15.0499 -0.0525737 15.3195 0.261921C15.589 0.576415 15.5526 1.04989 15.2381 1.31946L8.23811 7.31946C7.95724 7.5602 7.54279 7.5602 7.26192 7.31946L0.26192 1.31946C-0.0525743 1.04989 -0.0889955 0.576414 0.180571 0.26192Z"
			fill="currentColor"
		/>
	</svg>
)
